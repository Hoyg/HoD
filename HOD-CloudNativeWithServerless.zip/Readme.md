# Introduction 
 
Azure offers a comprehensive set of cloud platform services that make it easy to navigate architectural approaches and design patterns for building modern apps. It delivers numerous options for application development and deployment. In addition, Serverless architecture, a popular choice for cloud native applications, includes: 
* Event-driven functions—without the need to explicitly provision or manage infrastructure—with **Azure Functions**
* Globally distributed, multi-model databases with **Azure Cosmos DB**.
* Highly available and redundant storage with **Azure Storage**. 
* More than 200 out-of-the-box connectors using **Logic Apps** to integrate apps, data, systems, and services.
* Use **Event Grid** to power your event-driven and serverless apps.

# Demo Scenario
In this demo we are showing the capabilities and advantages to built cloud native apps in Microsoft Azure. 

This demo is based on SmartHotel360, which is a fictitious smart hospitality company showcasing the future of connected travel.

In this scenario we built a website in Node.js to analyze customer sentiment from Twitter by using Text Analysis Cognitive Services APIs. This website was built with Visual Studio Code and we used Azure services like Cosmos DB, Functions, and Logic Apps.

![](Images/SmartHotel360.png)

# Getting Started

1. Lets logging into the Virtual Machine with the following credentials:

```
Username: CloudNative\herosolutions 
Password: Pa$$w0rd!
```

2. Lets clone the repo of our solution for this we can use the shortcut in the desktop called **Clone** or we can use the following command:

```
git clone https://azuredemosolutions.visualstudio.com/CloudNative/_git/CloudNative
```
![](Images/1-Clonning.png)

3. Open Visual Studio Code and open the folder of ARM inside the repository we just cloned. Open the PowerShell script file called **Deploy-AzureResourceGroup.ps1** and automatically the PowerShell Integrated terminal will open, type the following command and wait until finish, it can take up to 8 minutes.
```
PS C:\Repos\CloudNative\arm> .\Deploy-AzureResourceGroup.ps1
```
4. Open Visual Studio Code and open the folder of ARM inside the repository we just cloned. Open the PowerShell script file called **Deploy-AzureResourceGroup.ps1** and automatically the PowerShell Integrated terminal will open, type the following command and wait until finish, it can take up to 8 minutes.
```
PS C:\Repos\CloudNative\arm> .\Deploy-AzureResourceGroup.ps1
```
![](Images/2-DeployingResources.png)

## Azure Resources

Once deployed we have created a resource group with all the services required for this demo app.

5. We need to create a database and collections in each Cosmos DB, for the Graph and SQL API, we need to go to **Data Explorer** in each service and click on new **Collection** and new **Graph** then provide the name **TweetsDB** and collection **Tweets**.

![](Images/3-GraphCosmosDB.png)
![](Images/4-SQLCosmosDB.png)

## Azure Logic App

6. In the Logic App we will need to select the common trigger called **when a new tweet is posted** then we will need to **Sing in** in Twitter with the following credentials:

```
Username: MeyerNathaly
Password: Pa$$w0rd2018!
```
![](Images/5-LogicAppTwitter.png)

7. Click on **Continue** to define the hashtag you want to monitor, by default we can use **#SmartHotel360** also as part of the configuration we click on **Edit** to modify the frequency, in this case we are going to use **3 seconds**.

![](Images/6-LogicAppHashtag.png)

8. Click on **New step**, here we will need to click on **Add an action** and type **Cosmos** then select **Create or update document**. 

![](Images/7-LogicAppCosmos.png)


9. Provide a name for the connection, in this case we used **CosmosDBConnection** then select the SQL API Cosmos DB (it starts with sh360dbsql*******), then click on **Create** and select the **TweetsDB**, Collection **Tweets** and paste the following code as part of **Document** then click on **Save** and **Run**.

```
{
    "created": "@triggerBody()?['CreatedAtIso']",
    "id": "@triggerBody()?['TweetId']",
    "text": "@triggerBody()?['TweetText']",
    "user": "@{triggerBody()?['TweetedBy']}"
}
```

![](Images/8-LogicAppCosmos.png)

## Azure Function

10. In Visual Studio Code open the **Function** folder. Here we need to open the **local.settings.json** file and provide the string connections for Azure Storage, Cosmos DB (SQL API) and Cognitive API. You can find those connections strings in the Azure Portal or you can use the Azure extension in Visual Studio Code to copy the Connection Strings.

![](Images/9-FunctionSettings.png)

11. Save and close the file and open the **dbconfig.js** file located in the AnalizePendingTweet folder, here we need to provide the endpoint and key as the string connection of the Graph API, we can find it in the Azure Portal or in the Azure extension inside Visual Studio Code. The endpoint must not include the protocol (https://) neither the port number.

![](Images/10-GraphEndpoint.png)

![](Images/11-GraphDbConnection.png)

12. Save and close the file. We need to add the npm package required for connecting to Cosmos DB Graph API in the integrated terminal (View) execute the following command: 

```
func extensions install --package Microsoft.Azure.WebJobs.Extensions.CosmosDB --version 3.0.0-beta7
```
![](Images/12-AddingCosmosDB.png)


13. After adding the package, we need to move inside the AnalyzePendingTweet folder and execute the following command in order to restore the packages.
```
cd AnalyzePendingTweet
npm install
```
![](Images/13-RestoringPackages.png)

## Debugging the Azure Function

14. We are ready to debug the Azure Function locally, we can press F5 or use the debug button in Visual Studio Code. 

![](Images/14-FunctionDebugging.png)

15. We need to post a tweet with the hashtag we specified.

![](Images/15-NewTweet.png)

16. In the Azure Portal we can navigate to the Logic App service and we can find the execution of the trigger we created.

![](Images/16-TweetLogicApp.png)

17. In Visual Studio Code, you can see in the terminal while debugging when the tweet was captured from the Cosmos SQL DB and stored in the Cosmos Graph DB.

![](Images/17-TweetStored.png)

18. We can stop the debugging now and with the Azure extension we can navigate into the Cosmos Graph DB and click on the **TweetsDB** here we can query the Graph and see the data inside of it.

![](Images/18-GraphData.png)

19. Now the Function is ready to be publish we can deploy by just right-click in the Function folder and using the option **Deploy to Function App**, this will create a package and deploying into the Azure function App we created. We just need to select the subscription and the Function App.

![](Images/19-DeployingAzureFunction.png)

20. In the Azure Portal we can navigate to the Azure Function and verify that our Function was deployed and it is enabled.

![](Images/20-AzureFunctionDeployed.png)

## Sentiment Analysis Website

21. We need to open the **web** folder and open the file **dbcnfig.js** under the folder called **util** here we need to provide the same connection string we used for the Cosmos Graph DB. Then save and close the file.

![](Images/21-WebGraphDBConnection.png)

22. Navigate to the **webconfig.js** file located under the folder **js** inside the **client** folder. In this file we need to provide the **Bing Maps API Key** we can find it as part of the Azure Resources created.

![](Images/22-BingMapsAPI.png)

23. The website will help us to show an overview of the feedback received from Twitter. Since we only have one tweet we need to populate sample data in order to show the capabilities of the website. We need to uncomment the line 15 of the file **app.js**. Save and it leave it open before publishing the website we will need to comment this line back.

![](Images/23-SampleData.png)

24. Before running the website we need to restore the packages using the same command:

![](Images/24-RestoringPackages.png)

25. We are ready to debug the website, we can press F5 or use the Debug button in Visual Studio Code:

![](Images/25-DebuggingWeb.png)

26. After debugging we need to open a new tab in Edge and navigate to http://localhost:3000 you can click on one of that points to see the overview feedback of that Hotel point.

![](Images/26-WebLocal.png)

27. We can stop the debugging and **comment** back the line 15 in the **app.js** file. We can execute a new query in the Cosmos Graph DB to see the sample data. 

![](Images/27-SampleGraph.png)

28. To publish the website in Azure we need to execute a docker compose, open the **Command Palette** by pressing Ctrl+Shift+P or it is located in the View tab of Visual Studio Code. Then select **Docker: Compose Up** and select the **docker-compose.yml** 

![](Images/28-DockerCompose.png)

29. We need to connect to the Azure Container Registry and push the docker image we just created. Navigate to Azure Portal and select the Azure Container Registry under Access Key you will find the Username, Password and Login Server. Execute the following commands:

```
docker login -u {username} -p {password} {loginServer}
docker tag webapp:latest {loginServer}/webapp
docker push {loginServer}/webapp
```
![](Images/29-DockerLogin.png)

30. After pushing the image to the Azure Container Registry we can use the Azure Portal to deploy the image as Azure App Service or we can use the Docker extension in Visual Studio Code, selecting the image under the Azure Container Registry and right-click on it and select **Deploy Image to Azure App Service**. Select the Resource Group, Hosting Plan and provide a name for the App Service.

![](Images/30-AzureWeb.png)

## Summary

Cloud Native apps are revolutionizing the way we develop and run applications. Here in this demo, we showed how you can build a cloud-native application using some of the technologies such as Containers, Serverless with Azure Functions,Cosmos DB, etc., quickly and easily with Azure. Get started [here in Azure](https://azure.microsoft.com).